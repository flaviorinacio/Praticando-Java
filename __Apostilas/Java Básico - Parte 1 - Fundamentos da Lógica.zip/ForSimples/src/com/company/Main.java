package com.company;

public class Main {

    public static void main(String[] args) {
        int i;

        for(i = 0; i < 10; i++){

            //Imprime i e pula uma linha
            System.out.println(i);

            //Quando chega aqui, o código volta para
            //a linha 8 e verifica se a condição
            //i <= 10 continua verdadeira, para
            //executar o laço novamente ou sair
        }
    }
}
