package com.company;

public class Main {

    public static void main(String[] args) {
        int i = 0;

        while(i <= 10){

            //Imprime i e pula uma linha
            System.out.println(i);

            //Aumenta em 1 o valor do i atual
            i = i + 3;

            //Quando chega aqui, o código volta para
            //a linha 8 e verifica se a condição
            //i <=10 continua verdadeira, para
            //executar o laço novamente ou sair
        }

    }
}
