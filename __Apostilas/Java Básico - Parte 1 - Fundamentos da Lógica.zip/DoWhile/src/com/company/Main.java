package com.company;

public class Main {

    public static void main(String[] args) {

        int i = 10;

        do{

            System.out.println("Vai ser executado ao menos uma vez");
            System.out.println("Mesmo que a condição seja falsa");

        }while(i < 5);

    }
}