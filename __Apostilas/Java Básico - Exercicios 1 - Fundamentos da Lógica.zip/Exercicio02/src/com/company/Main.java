package com.company;

public class Main {

    public static void main(String[] args) {
	    // FAÇA UM PROGRAMA QUE MOSTRE O RESULTADO DA SOMA DE 3 NÚMEROS QUEBRADOS
        double a = 5.5;
        double b = 6.7;
        double c = 9.3;
        double resultado = a + b + c;
        System.out.println("Resultado:" + resultado);
    }
}
