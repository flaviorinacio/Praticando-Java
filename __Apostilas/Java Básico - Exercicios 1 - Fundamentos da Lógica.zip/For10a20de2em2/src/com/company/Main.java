package com.company;

public class Main {

    public static void main(String[] args) {
	    // FAÇA UM PROGRAMA QUE
        // -IMPRIMA NA TELA OS NÚMEROS
        // -DE 10 A 20
        // -DE 2 EM 2

        int i = 0;

        for(i = 10; i <= 20; i = i + 2){
            System.out.println(i);
        }
    }
}
