package com.introducao.AulaIntroducaoAoJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaIntroducaoAoJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaIntroducaoAoJavaApplication.class, args);
	}

}
